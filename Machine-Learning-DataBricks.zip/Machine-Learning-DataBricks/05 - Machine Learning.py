# Databricks notebook source
# MAGIC %md
# MAGIC 05 - Machine Learning

# COMMAND ----------

# MAGIC %pip install -U datasets transformers tf-keras accelerate mlflow torchvision deepspeed 
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from io import BytesIO
from PIL import Image
import pandas as pd
import torch
import mlflow
import mlflow.pyfunc
from pyspark.sql.functions import pandas_udf, col
from datasets import Dataset
from transformers import AutoImageProcessor, AutoModelForImageClassification, Trainer, TrainingArguments, pipeline
from mlflow.models import infer_signature

# COMMAND ----------

# MAGIC %md
# MAGIC